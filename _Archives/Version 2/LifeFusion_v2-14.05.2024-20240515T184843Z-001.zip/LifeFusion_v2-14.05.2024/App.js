import React from "react";
import { createNativeStackNavigator } from "@react-navigation/native-stack";
import { NavigationContainer, TransitionPresets} from "@react-navigation/native";
import { SafeAreaProvider, SafeAreaView } from "react-native-safe-area-context";
import { ConnectScreen } from "./Screens/ConnectScreen/ConnectScreen.jsx";
import { RegisterScreen } from "./Screens/RegisterScreen/RegisterScreen";
import { LoggedScreen } from "./Screens/LoggedScreen/LoggedScreen";
import { s } from "./App.style";

const Stack = createNativeStackNavigator();

export default function App() {
  return (
    <SafeAreaProvider>
      <SafeAreaView style={s.container}>
        <NavigationContainer >
          <Stack.Navigator>         
            <Stack.Screen name="Connect" component={ConnectScreen} options={{headerShown:false}} />
            <Stack.Screen name="Register" component={RegisterScreen} options={{headerShown:false}}/>
            <Stack.Screen name="Logged" component={LoggedScreen} options={{headerShown:false}}/>
          </Stack.Navigator>
        </NavigationContainer>
      </SafeAreaView>
    </SafeAreaProvider>
  );
}
