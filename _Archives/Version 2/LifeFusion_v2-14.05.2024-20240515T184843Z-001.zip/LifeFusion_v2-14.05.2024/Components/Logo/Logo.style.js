import { StyleSheet } from "react-native";

export const s = StyleSheet.create ({

    image : {        
        marginVertical:30,
        width: 225,
        height: 140,
        resizeMode:"contain",
    }
})