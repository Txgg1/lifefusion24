import { StyleSheet } from "react-native";

export const s = StyleSheet.create ({

btnPurple : {
    width:320,
    backgroundColor:'#450045',
    marginTop:50,
    marginHorizontal:130,
    borderRadius: 25,
    padding: 10
},
txtPurple : {
    color: '#450045',
    fontSize:20,
    fontWeight:"bold",
    textTransform:"uppercase",
    textAlign:'center'
},
btnWhite : {
    width:320,
    backgroundColor:'white',
    marginVertical:60,
    marginHorizontal:130,
    borderWidth: 2,
    borderColor: '#450045',
    borderRadius: 25,
    padding: 10
},
txtWhite : {
    color: 'white',
    fontSize:20,
    fontWeight:"bold",
    textTransform:"uppercase",
    textAlign:'center',
},


})