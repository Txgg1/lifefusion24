import { StyleSheet } from "react-native";

export const s = StyleSheet.create ({

txtSubtitle : {
    textAlign:"center",
    color:'#450045',
    fontStyle:'italic',
    fontSize:28,
},

})