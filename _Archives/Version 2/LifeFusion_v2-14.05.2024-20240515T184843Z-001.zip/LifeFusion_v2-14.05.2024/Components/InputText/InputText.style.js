import { StyleSheet } from "react-native";

export const s = StyleSheet.create ({

    txtInput : {
    width:300,
    textAlign:"center",
    color:'#450045',
    textAlign:'left',
    paddingStart:25,
    marginVertical:20,
    fontSize:15,
    borderWidth: 3,
    borderColor: '#450045',
    borderRadius: 20,
    padding: 5
    },

})