import { StyleSheet } from "react-native";

export const s = StyleSheet.create ({

container    : {
    width:"95%",
    alignItems:'center',    
}

})