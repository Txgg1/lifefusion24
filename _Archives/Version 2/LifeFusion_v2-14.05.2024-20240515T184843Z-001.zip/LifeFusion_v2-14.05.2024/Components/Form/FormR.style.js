import { StyleSheet } from "react-native";

export const s = StyleSheet.create({
  container: {
    marginTop:100,
    width: "95%",
    alignItems:"center",
    justifyContent: "center",
  },
  txtTitle: {
    width: 280,
    textTransform: "uppercase",
    color: "#450045",
    fontSize: 28,
    fontWeight: "bold",
  },
  txtSubtitle: {
    textAlign:"center",
    width: 220,
    marginBottom: 15,
    fontStyle: "italic",
    fontSize: 18,
  },
  txtInput: {
    width:480,
    height:50,
    color:'#450045',
    textAlign:'left',
    paddingStart:25,
    marginVertical:30,
    fontSize:15,
    fontStyle:"italic",
    fontWeight:"bold",
    color:"#450045",
    borderWidth: 3,
    borderColor: '#450045',
    borderRadius: 25,
    padding: 5
  }
});
