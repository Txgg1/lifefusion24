import React, { useState } from "react";
import { View } from "react-native";
import { useNavigation } from '@react-navigation/native';
import { Title } from "../Title/Title";
import { Subtitle } from "../Subtitle/Subtitle";
import { InputText } from "../InputText/InputText";
import { Button } from "../Button/Button";
import { FormC } from "./FormC";
import { FormL } from "./FormL";
import { FormR } from "./FormR";

export function Form() {
  const navigation = useNavigation();
  const [formType, setFormType] = useState("connexion");

  const handleConnexionPress = () => {
    navigation.navigate("Connect");
  };

  const handleInscriptionPress = () => {
    navigation.navigate("Register");
  };

  const renderForm = () => {
    switch (formType) {
      case "connexion":
        return <FormC />;
      case "inscription":
        return <FormR />;
      case "logged":
        return <FormL />;
      default:
        return null;
    }
  };

  return (
    <View>
      <Title txtTitle="Unified Form" />
      <Subtitle txtSubtitle="Select form type:" />
      <Button type="connexion" title="Connexion" onPress={() => setFormType("connexion")} />
      <Button type="inscription" title="Inscription" onPress={() => setFormType("inscription")} />
      <Button type="logged" title="Logged" onPress={() => setFormType("logged")} />
      {renderForm()}
      <Button type="connexion" title="Connexion" onPress={handleConnexionPress} />
      <Button type="inscription" title="Inscription" onPress={handleInscriptionPress} />
    </View>
  );
}
