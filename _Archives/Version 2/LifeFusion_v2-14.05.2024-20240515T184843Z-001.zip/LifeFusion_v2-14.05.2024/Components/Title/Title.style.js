import { StyleSheet } from "react-native";

export const s = StyleSheet.create ({

txtTitle : {
    textAlign:"center",
    color:'#450045',
    fontSize:40,
},

})