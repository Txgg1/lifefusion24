import { StyleSheet } from "react-native";

export const s = StyleSheet.create ({

    container : {        
      width:"100%",
      height:"100%",
        
    },

 
   
   
})